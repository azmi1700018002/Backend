<?php

namespace App\Models;

use CodeIgniter\Model;
use Exception;

class BdyKerjaModel extends Model
{
    protected $table = 'dbo_konten';
    protected $primaryKey = 'konten_id';
    protected $allowedFields = [
        'konten_parent',
        'konten_urut',
        'konten_menu',
       
    ];
   
    protected $updatedField = 'updated_at';

    public function getAllBdyKerja(){
   
       $query = $this->db->table('dbo_konten')
       ->where('konten_parent = 96')
       ->join('dbo_kategori' , 'dbo_konten.kategori_id = dbo_kategori.kategori_id')
       ->orderBy('konten_id','asc')
       ->get()->getResultArray();  

       return $query;
    }

    // public function findKonvenById($id)
    // {
    //     $produk_konven = $this
    //         ->asArray()
    //         ->where(['produk_konven_id' => $id])
    //         ->first();
    //     $produk_konven->join('tipe', 'produk_konven.tipe_id = tipe.tipe_id');
    //     $produk_konven->orderBy("produk_konven_id", "asc");
    //     if (!$produk_konven) throw new Exception('Could not find client for specified ID');

    //     return $produk_konven;
    // }
    
}