<?php namespace App\Controllers;

use App\Models\IdentitasModel;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\HTTP\Response;
use Exception;
 
class IdentitasPribadi extends BaseController
{
    use ResponseTrait;
    // get all product
    public function index()
    {
        $model = new IdentitasModel();
        $data = $model->getAllIdentitas();
        return $this->respond($data);
    }
 
    // get single product
    public function show($konten_parent)
    {
        try {
            $model = new IdentitasModel();
            $data = $model->getAllIdentitas($konten_parent);

            return $this->getResponse(
                [
                    'message' => 'Identitas Pribadi retrieved successfully',
                    'identitaspribadi' => $data
                ]
            );
        } catch (Exception $e) {
            return $this->getResponse(
                [
                    'message' => 'Could not find client for specified ID'
                ],
                ResponseInterface::HTTP_NOT_FOUND
            );
        }
    }
 
    // create a product
    public function create()
    {
        $model = new IdentitasModel();
        $data = [
            'nama_menu' => $this->request->getVar('nama_menu'),
            'status' => $this->request->getVar('status'),
            'tipe_id' => $this->request->getVar('tipe_id'),
        ];
        $model->insert($data);
        $response = [
            'status'   => 201,
            'error'    => null,
            'messages' => [
                'success' => 'Data Saved'
            ]
        ];
        return $this->respondCreated($response);
    }
 
    // update product
    public function update($id = null)
    {
        $model = new IdentitasModel();
        $input = $this->request->getRawInput();
        $data = [
            'nama_menu' => $input['nama_menu'],
            'status' => $input['status'],
            'tipe_id' => $input['tipe_id'],
        ];
        $model->update($id, $data);

        $response = [
            'status'   => 200,
            'error'    => null,
            'messages' => [
                'success' => 'Data Updated'
            ]
        ];
        return $this->respond($response);
    }
 
    // delete product
    public function delete($id = null)
    {
        $model = new IdentitasModel();
        $data = $model->find($id);
        if($data){
            $model->delete($id);
            $response = [
                'status'   => 200,
                'error'    => null,
                'messages' => [
                    'success' => 'Data Deleted'
                ]
            ];
            return $this->respondDeleted($response);
        }else{
            return $this->failNotFound('No Data Found with id '.$id);
        }
         
    }
 
}